import React, { useState, useRef } from 'react';
import { AppState, ClinicSettings, Patient, PaymentModal } from '../types';
import { Save, Building, Mail, Phone, MapPin, User, CheckCircle, Database, Download, Upload } from 'lucide-react';
import Papa from 'papaparse';

interface SettingsProps {
  state: AppState;
  onUpdate: (newState: Partial<AppState>) => void;
}

export default function Settings({ state, onUpdate }: SettingsProps) {
  const [settings, setSettings] = useState<ClinicSettings>(state.settings);
  const [success, setSuccess] = useState(false);
  const [importSuccess, setImportSuccess] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    onUpdate({ settings });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
  };

  const exportCSV = () => {
    const data = state.patients.map(p => ({
      ID: p.id,
      Nome: p.name,
      'Data de Nascimento': p.birthDate,
      Responsável: p.guardianName,
      WhatsApp: p.whatsapp,
      'Dia Fixo': p.fixedDay,
      'Horário Fixo': p.fixedTime,
      'Modalidade Pagamento': p.paymentModal,
      'Data de Início': p.startDate,
      Escola: p.school || '',
      Série: p.grade || '',
      Turno: p.shift || '',
      Médico: p.doctorName || '',
      Medicação: p.medication || '',
      Status: p.status || 'Ativo',
      Anotações: p.clinicalNotes || ''
    }));

    const csv = Papa.unparse(data, { delimiter: ';' });
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'backup_atendentes.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFileUploadAction = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const rows = results.data as any[];
          const newPatients: Patient[] = rows.map(row => {
            const tempPatient = state.patients.find(p => p.id === row.ID);
            return {
              id: row.ID || Date.now().toString() + Math.random().toString(36).substring(2, 9),
              name: row.Nome,
              birthDate: row['Data de Nascimento'],
              guardianName: row.Responsável,
              whatsapp: row.WhatsApp,
              fixedDay: row['Dia Fixo'],
              fixedTime: row['Horário Fixo'],
              paymentModal: (row['Modalidade Pagamento'] as PaymentModal) || PaymentModal.PIX_FULL,
              startDate: row['Data de Início'],
              school: row.Escola,
              grade: row.Série,
              shift: row.Turno,
              doctorName: row.Médico,
              medication: row.Medicação,
              status: row.Status === 'Concluído' ? 'Concluído' : 'Ativo',
              clinicalNotes: row.Anotações || tempPatient?.clinicalNotes || '',
              anamnese: tempPatient?.anamnese || {
                complaint: '',
                school: '',
                grade: '',
                referredBy: '',
                diagnoses: '',
                initialNotes: ''
              }
            };
          });

          const mergedPatients = [...state.patients];
          newPatients.forEach(p => {
            const index = mergedPatients.findIndex(ex => ex.id === p.id);
            if (index >= 0) {
              mergedPatients[index] = { ...mergedPatients[index], ...p };
            } else {
              mergedPatients.push(p);
            }
          });

          onUpdate({ patients: mergedPatients });
          setImportSuccess('Dados importados com sucesso!');
          setTimeout(() => setImportSuccess(''), 4000);
        } catch (err) {
          console.error(err);
          setImportSuccess('Erro ao importar arquivo. Verifique o formato do CSV.');
          setTimeout(() => setImportSuccess(''), 4000);
        }
        if (e.target) e.target.value = '';
      }
    });
  };

  return (
    <div className="flex flex-col gap-6 py-6 pb-20">
      <div className="bg-clinic-surface rounded-2xl border border-clinic-border p-8 shadow-clinic max-w-2xl mx-auto w-full">
        <h2 className="font-serif text-2xl font-bold text-clinic-text mb-6 flex items-center gap-2">
          <Building className="text-clinic-primary" />
          Configurações da Clínica
        </h2>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Nome Profissional</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-clinic-text-faint" size={16} />
                <input 
                  type="text" 
                  value={settings.name}
                  onChange={(e) => setSettings({...settings, name: e.target.value})}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm font-bold"
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Especialidade / Título</label>
              <input 
                type="text" 
                value={settings.specialty}
                onChange={(e) => setSettings({...settings, specialty: e.target.value})}
                className="w-full px-4 py-2.5 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm font-bold"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Descrição Curta (Header)</label>
            <input 
              type="text" 
              value={settings.title}
              onChange={(e) => setSettings({...settings, title: e.target.value})}
              className="w-full px-4 py-2.5 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm font-bold"
              placeholder="Ex: Neuropsicopedagogia"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-clinic-text-faint" size={16} />
                <input 
                  type="email" 
                  value={settings.email}
                  onChange={(e) => setSettings({...settings, email: e.target.value})}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm font-bold"
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">WhatsApp</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-clinic-text-faint" size={16} />
                <input 
                  type="text" 
                  value={settings.whatsapp}
                  onChange={(e) => setSettings({...settings, whatsapp: e.target.value})}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm font-bold"
                />
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Endereço Completo</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-clinic-text-faint" size={16} />
              <input 
                type="text" 
                value={settings.address}
                onChange={(e) => setSettings({...settings, address: e.target.value})}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm font-bold"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-clinic-border">
            <h3 className="font-serif font-bold text-lg text-clinic-text mb-4">Personalização da Plataforma e Relatórios</h3>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Cabeçalho Personalizado (opcional)</label>
                <textarea 
                  value={settings.customHeader || ''}
                  onChange={(e) => setSettings({...settings, customHeader: e.target.value})}
                  className="w-full p-4 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm"
                  placeholder="Se preenchido, substituirá o cabeçalho padrão na plataforma e nos relatórios em PDF..."
                  rows={2}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-clinic-text-faint ml-1">Rodapé Personalizado (opcional)</label>
                <textarea 
                  value={settings.customFooter || ''}
                  onChange={(e) => setSettings({...settings, customFooter: e.target.value})}
                  className="w-full p-4 rounded-xl border border-clinic-border bg-white focus:ring-2 focus:ring-clinic-primary outline-none transition-all text-sm"
                  placeholder="Se preenchido, substituirá o rodapé padrão na plataforma e nos relatórios em PDF..."
                  rows={2}
                />
              </div>
            </div>
          </div>

          <button 
            onClick={handleSave}
            className="w-full mt-8 bg-clinic-primary hover:bg-clinic-primary-hover text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95"
          >
            {success ? (
              <><CheckCircle size={20} /> Alterações Salvas!</>
            ) : (
              <><Save size={20} /> Salvar Configurações</>
            )}
          </button>
        </div>
      </div>

      <div className="bg-clinic-surface rounded-2xl border border-clinic-border p-8 shadow-clinic max-w-2xl mx-auto w-full">
        <h2 className="font-serif text-2xl font-bold text-clinic-text mb-2 flex items-center gap-2">
          <Database className="text-clinic-primary" />
          Backup e Importação (Planilha)
        </h2>
        <p className="text-sm text-clinic-text-muted mb-6">
          Exporte seus dados para gerar um backup no formato de planilha (CSV). 
          Você também pode adicionar novos atendentes através da planilha e importar o arquivo abaixo para registrar em lote.
        </p>

        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <button 
            onClick={exportCSV}
            className="flex-1 bg-clinic-primary hover:bg-clinic-primary-hover text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95"
          >
            <Download size={20} /> Exportar Atendentes (CSV)
          </button>
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 bg-white hover:bg-clinic-bg text-clinic-text py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-md border border-clinic-border transition-all active:scale-95"
          >
            <Upload size={20} className="text-clinic-primary" /> Importar Planilha (CSV)
          </button>
          <input 
            type="file" 
            accept=".csv" 
            ref={fileInputRef} 
            onChange={handleFileUploadAction} 
            className="hidden" 
          />
        </div>
        
        {importSuccess && (
          <div className="p-3 mt-4 rounded-xl text-center text-sm font-bold border border-status-green-text bg-status-green-bg text-status-green-text">
            {importSuccess}
          </div>
        )}
      </div>

      <div className="max-w-2xl mx-auto w-full text-center text-clinic-text-faint text-xs opacity-50">
        As alterações acima são aplicadas instantaneamente no topo e rodapé da aplicação.
      </div>
    </div>
  );
}
