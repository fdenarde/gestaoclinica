import React, { useState, useMemo } from 'react';
import { AppState, Payment, PaymentModal, SessionStatus } from '../types';
import { DollarSign, Plus, Search, Calendar, User, AlertCircle, History, Trash2 } from 'lucide-react';
import { formatCurrency, cn, getStatusColor, safeFormatDate } from '../lib/utils';
import { format } from 'date-fns';
import Modal from './Common/Modal';
import { showToast } from './Common/Toast';

interface FinanceProps {
  state: AppState;
  onUpdate: (newState: Partial<AppState>) => void;
}

export default function Finance({ state, onUpdate }: FinanceProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentToDelete, setPaymentToDelete] = useState<string | null>(null);

  // Form State
  const [patientId, setPatientId] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [installment, setInstallment] = useState<'1ª parcela' | '2ª parcela' | 'Pagamento integral'>('Pagamento integral');
  const [method, setMethod] = useState<'Pix' | 'Dinheiro' | 'Transferência' | 'Outro'>('Pix');

  const metrics = useMemo(() => {
    const now = new Date();
    const monthlyReceived = state.payments
      .filter(p => {
        const d = new Date(p.date);
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      })
      .reduce((sum, p) => sum + p.amount, 0);

    const activePackages = state.patients.filter(p => p.status === 'Ativo').length;
    
    // Total to receive logic
    let totalToReceive = 0;
    state.patients.filter(p => p.status === 'Ativo').forEach(patient => {
      const paid = state.payments.filter(p => p.patientId === patient.id).reduce((s, p) => s + p.amount, 0);
      const totalExpected = 1000; // Package fixed price
      if (paid < totalExpected) {
        totalToReceive += (totalExpected - paid);
      }
    });

    return { monthlyReceived, totalToReceive, activePackages };
  }, [state]);

  const handleSavePayment = () => {
    if (!patientId || amount <= 0) {
      showToast('Preencha os dados corretamente.', 'error');
      return;
    }

    const newPayment: Payment = {
      id: Math.random().toString(36).substr(2, 9),
      patientId,
      amount,
      date,
      installment,
      method
    };

    onUpdate({ payments: [...state.payments, newPayment] });
    showToast('Pagamento registrado com sucesso!');
    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setPatientId('');
    setAmount(0);
    setDate(format(new Date(), 'yyyy-MM-dd'));
    setInstallment('Pagamento integral');
    setMethod('Pix');
  };

  const filteredPatientsFinance = useMemo(() => {
    return state.patients
      .filter(p => p.status === 'Ativo')
      .map(patient => {
        const patientPayments = state.payments.filter(p => p.patientId === patient.id);
        const totalPaid = patientPayments.reduce((sum, p) => sum + p.amount, 0);
        const totalExpected = 1000;
        const remaining = totalExpected - totalPaid;
        
        // Status logic
        let status: 'Quitado' | 'Parcial' | 'Pendente' = 'Pendente';
        if (totalPaid >= totalExpected) status = 'Quitado';
        else if (totalPaid > 0) status = 'Parcial';

        // High priority check
        const sessionCount = state.sessions.filter(s => s.patientId === patient.id && (s.status === SessionStatus.REALIZADA || s.status === SessionStatus.REPOSICAO)).length;
        const isLate = patient.paymentModal === PaymentModal.PARCELADO && sessionCount >= 6 && !patientPayments.some(p => p.installment === '2ª parcela');

        return { ...patient, totalPaid, remaining, status, isLate };
      })
      .filter(p => {
        const normalize = (str: string) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        return normalize(p.name).includes(normalize(searchTerm));
      })
      .sort((a,b) => b.isLate ? 1 : -1);
  }, [state, searchTerm]);

  return (
    <div className="flex flex-col gap-6 py-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Recebido no Mês', value: formatCurrency(metrics.monthlyReceived), sub: `${state.payments.length} transações` },
          { label: 'Saldo a Receber', value: formatCurrency(metrics.totalToReceive), sub: 'baseado em pacotes ativos' },
          { label: 'Pacotes Ativos', value: metrics.activePackages, sub: 'R$ 1.000,00 padrão/ciclo' },
        ].map((item, idx) => (
          <div key={idx} className="bg-clinic-surface p-6 rounded-2xl border border-clinic-border shadow-clinic flex flex-col">
            <p className="text-[10px] uppercase font-bold text-clinic-text-faint mb-1">{item.label}</p>
            <p className="text-3xl font-serif font-bold text-clinic-text">{item.value}</p>
            <p className="text-[10px] text-clinic-text-muted mt-1 uppercase tracking-tight font-medium opacity-70">{item.sub}</p>
          </div>
        ))}
      </div>

      {/* Header with Search and Add */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-clinic-surface p-4 rounded-2xl border border-clinic-border shadow-sm">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-clinic-text-faint" size={20} />
          <input 
            type="text" 
            placeholder="Buscar por atendente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-clinic-bg rounded-xl border border-clinic-border focus:ring-2 focus:ring-clinic-primary outline-none transition-all"
          />
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-6 py-3 bg-clinic-primary text-white font-bold rounded-xl shadow-lg hover:bg-clinic-primary-hover transition-all uppercase tracking-widest text-xs w-full md:w-auto justify-center"
        >
          <Plus size={18} />
          Registrar Pagamento
        </button>
      </div>

      {/* Financial Status List */}
      <div className="bg-clinic-surface rounded-2xl border border-clinic-border shadow-sm">
        <div className="px-6 py-4 border-b border-clinic-border flex items-center gap-2">
          <DollarSign size={20} />
          <h2 className="font-serif text-xl font-bold">Situação por Atendente</h2>
        </div>
        <div className="p-6 space-y-4">
          {filteredPatientsFinance.map(item => (
            <div key={item.id} className={cn(
              "p-4 rounded-xl border transition-all flex flex-col md:flex-row items-center gap-4",
              item.isLate ? "bg-status-red-bg border-red-200" : "bg-white border-clinic-border hover:bg-clinic-bg/40"
            )}>
              <div className="flex-1 w-full text-center md:text-left">
                <div className="flex flex-col md:flex-row md:items-center gap-2">
                  <h4 className="font-bold text-clinic-text">{item.name}</h4>
                  <span className="text-[10px] text-clinic-text-faint font-bold uppercase px-2 py-0.5 bg-clinic-bg rounded">{item.paymentModal.split(': ')[0]}</span>
                  {item.isLate && <span className="text-[10px] font-black uppercase text-status-red-text animate-pulse">⚠️ Pagamento em Atraso</span>}
                </div>
                <div className="text-xs text-clinic-text-muted mt-1">
                  Saldo Restante: <span className="font-bold text-clinic-text">{formatCurrency(item.remaining)}</span>
                </div>
              </div>
              
              <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end">
                <div className="flex flex-col items-end">
                   <span className="text-xs font-bold text-clinic-text-faint uppercase">Pago</span>
                   <span className="text-lg font-serif font-black text-clinic-text">{formatCurrency(item.totalPaid)}</span>
                </div>
                <div className={cn("px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest", getStatusColor(item.status))}>
                   {item.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Payment History List */}
      <div className="bg-clinic-surface rounded-2xl border border-clinic-border shadow-sm">
         <div className="px-6 py-4 border-b border-clinic-border flex items-center gap-2 bg-clinic-bg/10">
          <History size={20} className="text-clinic-text-faint" />
          <h2 className="font-serif text-xl font-bold">Histórico de Transações</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-clinic-bg/50 text-[10px] font-bold uppercase tracking-widest text-clinic-text-faint border-b border-clinic-border">
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Atendente</th>
                <th className="px-6 py-4">Parcela</th>
                <th className="px-6 py-4">Forma</th>
                <th className="px-6 py-4 text-right">Valor</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-clinic-border">
              {state.payments.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(p => (
                <tr key={p.id} className="hover:bg-clinic-bg/30 transition-colors group">
                  <td className="px-6 py-4 text-sm whitespace-nowrap">{safeFormatDate(p.date, 'dd/MM/yyyy')}</td>
                  <td className="px-6 py-4 text-sm font-bold text-clinic-text">{state.patients.find(pt => pt.id === p.patientId)?.name}</td>
                  <td className="px-6 py-4 text-xs">{p.installment}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-clinic-bg rounded text-[10px] font-bold text-clinic-text-muted">{p.method}</span>
                  </td>
                  <td className="px-6 py-4 text-right font-serif font-bold text-status-green-text flex items-center justify-end gap-3">
                    {formatCurrency(p.amount)}
                    <button 
                      onClick={() => setPaymentToDelete(p.id)}
                      className="p-1.5 text-status-red-text bg-status-red-bg rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Excluir Pagamento"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {state.payments.length === 0 && (
            <p className="py-10 text-center text-clinic-text-muted italic text-sm">Nenhum pagamento registrado.</p>
          )}
        </div>
      </div>

      <Modal
        isOpen={!!paymentToDelete}
        onClose={() => setPaymentToDelete(null)}
        title="Confirmar Exclusão"
        width="max-w-md"
      >
        <div className="space-y-6">
          <p className="text-clinic-text">
            Deseja realmente excluir este pagamento?
          </p>
          <div className="flex justify-end gap-3">
            <button
              onClick={() => setPaymentToDelete(null)}
              className="px-4 py-2 bg-clinic-bg text-clinic-text-muted font-bold rounded-lg hover:bg-clinic-border transition-all uppercase tracking-wide text-xs"
            >
              Cancelar
            </button>
            <button
              onClick={() => {
                if (paymentToDelete) {
                  onUpdate({ payments: state.payments.filter(pm => pm.id !== paymentToDelete) });
                  showToast('Pagamento excluído com sucesso');
                  setPaymentToDelete(null);
                }
              }}
              className="px-4 py-2 bg-status-red-text text-white font-bold rounded-lg shadow-md hover:bg-red-700 transition-all uppercase tracking-wide text-xs"
            >
              Excluir Pagamento
            </button>
          </div>
        </div>
      </Modal>

      {/* Modal Novo Pagamento */}
      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title="Registrar Novo Pagamento"
      >
        <div className="space-y-5">
           <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-clinic-text-faint uppercase">Atendente</label>
            <select 
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="px-4 py-3 bg-clinic-bg rounded-xl border border-clinic-border outline-none focus:ring-2 focus:ring-clinic-primary transition-all"
            >
              <option value="">Selecione o atendente...</option>
              {state.patients.filter(p => p.status === 'Ativo').sort((a,b) => a.name.localeCompare(b.name)).map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-clinic-text-faint uppercase">Valor (R$)</label>
              <input 
                type="number" 
                value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                className="px-4 py-3 bg-clinic-bg rounded-xl border border-clinic-border outline-none focus:ring-2 focus:ring-clinic-primary transition-all"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-clinic-text-faint uppercase">Data</label>
              <input 
                type="date" 
                value={date}
                onChange={e => setDate(e.target.value)}
                className="px-4 py-3 bg-clinic-bg rounded-xl border border-clinic-border outline-none focus:ring-2 focus:ring-clinic-primary transition-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-clinic-text-faint uppercase">Parcela</label>
              <select 
                value={installment}
                onChange={e => setInstallment(e.target.value as any)}
                className="px-4 py-3 bg-clinic-bg rounded-xl border border-clinic-border outline-none"
              >
                <option value="Pagamento integral">Pagamento integral</option>
                <option value="1ª parcela">1ª parcela</option>
                <option value="2ª parcela">2ª parcela</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-clinic-text-faint uppercase">Forma</label>
              <select 
                value={method}
                onChange={e => setMethod(e.target.value as any)}
                className="px-4 py-3 bg-clinic-bg rounded-xl border border-clinic-border outline-none"
              >
                <option value="Pix">Pix</option>
                <option value="Dinheiro">Dinheiro</option>
                <option value="Transferência">Transferência</option>
                <option value="Outro">Outro</option>
              </select>
            </div>
          </div>

          <button 
            onClick={handleSavePayment}
            disabled={!patientId || amount <= 0}
            className="w-full py-4 bg-clinic-primary text-white font-bold rounded-xl shadow-xl hover:bg-clinic-primary-hover transition-all uppercase tracking-widest disabled:opacity-50"
          >
            Confirmar Recebimento
          </button>
        </div>
      </Modal>
    </div>
  );
}
