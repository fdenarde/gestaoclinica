import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

export function calculateAge(birthDate: string | undefined | null): number | string {
  if (!birthDate) return '--';
  const birth = new Date(birthDate);
  if (isNaN(birth.getTime())) return '--';
  
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

export function safeFormatDate(dateStr: string | undefined | null, formatStr: string = 'dd/MM/yyyy'): string {
  if (!dateStr) return '--';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '--';
  
  try {
    return format(d, formatStr);
  } catch(e) {
    return '--';
  }
}


export function getStatusColor(status: string) {
  switch (status) {
    case 'Realizada':
    case 'Quitado':
      return 'bg-status-green-bg text-status-green-text';
    case 'Falta.Prof':
    case 'Parcial':
    case 'Pendente':
    case 'Laranja':
      return 'bg-status-orange-bg text-status-orange-text';
    case 'Falta':
    case 'Atraso':
    case 'Vermelho':
      return 'bg-status-red-bg text-status-red-text';
    case 'Reposição':
    case 'Info':
    case 'Azul':
      return 'bg-status-blue-bg text-status-blue-text';
    default:
      return 'bg-clinic-surface text-clinic-text-muted';
  }
}
